# ProGuard rules for AniWave Native
