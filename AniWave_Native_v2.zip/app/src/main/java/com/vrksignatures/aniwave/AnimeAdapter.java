package com.vrksignatures.aniwave;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

public class AnimeAdapter extends RecyclerView.Adapter<AnimeAdapter.VH> {

    public interface OnAnimeClickListener {
        void onAnimeClick(AnimeItem item);
    }

    private final Context context;
    private final OnAnimeClickListener listener;
    private List<AnimeItem> items = new ArrayList<>();
    private boolean useJapaneseTitle = false;

    public AnimeAdapter(Context context, OnAnimeClickListener listener) {
        this.context = context;
        this.listener = listener;
    }

    public void setItems(List<AnimeItem> newItems) {
        this.items = newItems != null ? newItems : new ArrayList<>();
        notifyDataSetChanged();
    }

    public void setUseJapaneseTitle(boolean useJp) {
        this.useJapaneseTitle = useJp;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_anime_card, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        AnimeItem item = items.get(position);
        String displayTitle = (useJapaneseTitle && item.jpTitle != null && !item.jpTitle.isEmpty())
                ? item.jpTitle : item.title;
        holder.tvTitle.setText(displayTitle);
        holder.tvType.setText(item.type != null && !item.type.isEmpty() ? item.type : "TV");

        if (item.subCount != null && !item.subCount.isEmpty()) {
            holder.tvSub.setVisibility(View.VISIBLE);
            holder.tvSub.setText("SUB " + item.subCount);
        } else {
            holder.tvSub.setVisibility(View.GONE);
        }

        if (item.dubCount != null && !item.dubCount.isEmpty()) {
            holder.tvDub.setVisibility(View.VISIBLE);
            holder.tvDub.setText("DUB " + item.dubCount);
        } else {
            holder.tvDub.setVisibility(View.GONE);
        }

        Glide.with(context)
                .load(item.posterUrl)
                .centerCrop()
                .into(holder.ivPoster);

        holder.itemView.setOnClickListener(v -> listener.onAnimeClick(item));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        ImageView ivPoster;
        TextView tvTitle, tvSub, tvDub, tvType;

        VH(@NonNull View itemView) {
            super(itemView);
            ivPoster = itemView.findViewById(R.id.ivPoster);
            tvTitle = itemView.findViewById(R.id.tvAnimeTitle);
            tvSub = itemView.findViewById(R.id.tvBadgeSub);
            tvDub = itemView.findViewById(R.id.tvBadgeDub);
            tvType = itemView.findViewById(R.id.tvBadgeType);
        }
    }
}
