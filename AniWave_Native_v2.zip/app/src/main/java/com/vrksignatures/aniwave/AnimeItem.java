package com.vrksignatures.aniwave;

public class AnimeItem {
    public String title;
    public String jpTitle;
    public String url;
    public String posterUrl;
    public String subCount;
    public String dubCount;
    public String type;

    public AnimeItem(String title, String jpTitle, String url, String posterUrl, String subCount, String dubCount, String type) {
        this.title = title;
        this.jpTitle = jpTitle;
        this.url = url;
        this.posterUrl = posterUrl;
        this.subCount = subCount;
        this.dubCount = dubCount;
        this.type = type;
    }
}
