package com.vrksignatures.aniwave;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.OptIn;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.PlaybackParameters;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.PlayerView;

import java.util.HashMap;
import java.util.Map;

public class PlayerActivity extends AppCompatActivity {

    private ExoPlayer player;
    private SharedPreferences prefs;
    private String streamKey = "";
    private final float[] speeds = {1.0f, 1.25f, 1.5f, 2.0f, 0.75f};
    private int speedIndex = 0;

    @OptIn(markerClass = UnstableApi.class)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideSystemUI();
        setContentView(R.layout.activity_player);

        prefs = getSharedPreferences("AniWaveResumePrefs", MODE_PRIVATE);
        PlayerView playerView = findViewById(R.id.playerView);
        TextView tvTitle = findViewById(R.id.tvPlayerTitle);
        TextView btnBack = findViewById(R.id.btnPlayerBack);
        TextView btnSpeed = findViewById(R.id.btnPlayerSpeed);

        String streamUrl = getIntent().getStringExtra("STREAM_URL");
        String referer = getIntent().getStringExtra("REFERER");
        String title = getIntent().getStringExtra("TITLE");

        if (title != null && !title.isEmpty()) {
            tvTitle.setText(title);
            streamKey = "pos_" + title.hashCode();
        }

        btnBack.setOnClickListener(v -> finish());

        if (streamUrl == null || streamUrl.isEmpty()) {
            Toast.makeText(this, "No video stream found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        Map<String, String> headers = new HashMap<>();
        headers.put("Referer", (referer != null && !referer.isEmpty()) ? referer : "https://aniwaves.tv/");
        headers.put("User-Agent", "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36");

        DefaultHttpDataSource.Factory dataSourceFactory = new DefaultHttpDataSource.Factory()
                .setAllowCrossProtocolRedirects(true)
                .setDefaultRequestProperties(headers);

        player = new ExoPlayer.Builder(this)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(dataSourceFactory))
                .build();

        playerView.setPlayer(player);
        player.setMediaItem(MediaItem.fromUri(streamUrl));
        player.prepare();

        long savedPos = prefs.getLong(streamKey, 0L);
        if (savedPos > 5000L) {
            player.seekTo(savedPos);
        }
        player.play();

        btnSpeed.setOnClickListener(v -> {
            speedIndex = (speedIndex + 1) % speeds.length;
            float s = speeds[speedIndex];
            player.setPlaybackParameters(new PlaybackParameters(s));
            btnSpeed.setText(s + "x");
        });

        player.addListener(new Player.Listener() {
            @Override
            public void onPlayerError(PlaybackException error) {
                Toast.makeText(PlayerActivity.this, "Stream error: " + error.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void hideSystemUI() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        );
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) {
            if (!streamKey.isEmpty()) {
                prefs.edit().putLong(streamKey, player.getCurrentPosition()).apply();
            }
            player.pause();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (player != null) {
            player.release();
            player = null;
        }
    }
}
