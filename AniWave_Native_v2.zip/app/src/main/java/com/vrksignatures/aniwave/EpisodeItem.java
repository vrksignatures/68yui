package com.vrksignatures.aniwave;

public class EpisodeItem {
    public String number;
    public String url;

    public EpisodeItem(String number, String url) {
        this.number = number;
        this.url = url;
    }
}
