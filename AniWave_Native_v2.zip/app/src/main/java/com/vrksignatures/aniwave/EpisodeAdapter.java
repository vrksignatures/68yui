package com.vrksignatures.aniwave;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class EpisodeAdapter extends RecyclerView.Adapter<EpisodeAdapter.VH> {

    public interface OnEpisodeClickListener {
        void onEpisodeClick(EpisodeItem episode);
    }

    private final Context context;
    private final OnEpisodeClickListener listener;
    private List<EpisodeItem> episodes = new ArrayList<>();

    public EpisodeAdapter(Context context, OnEpisodeClickListener listener) {
        this.context = context;
        this.listener = listener;
    }

    public void setEpisodes(List<EpisodeItem> list) {
        this.episodes = list != null ? list : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_episode, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        EpisodeItem ep = episodes.get(position);
        holder.tvEp.setText(ep.number);
        holder.itemView.setOnClickListener(v -> listener.onEpisodeClick(ep));
    }

    @Override
    public int getItemCount() {
        return episodes.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvEp;
        VH(@NonNull View itemView) {
            super(itemView);
            tvEp = itemView.findViewById(R.id.tvEpNumber);
        }
    }
}
