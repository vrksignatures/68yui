package com.vrksignatures.aniwave;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.io.ByteArrayInputStream;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DetailActivity extends AppCompatActivity {

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private EpisodeAdapter episodeAdapter;
    private WebView hiddenExtractor;
    private TextView tvDetailTitle, tvDetailHeader, tvDetailSynopsis, tvDetailMeta, tvExtractingStatus;
    private TextView btnModeSub, btnModeDub, btnServer1, btnServer2, btnServer3;
    private ImageView ivDetailPoster;

    private String animeTitle = "";
    private String animeUrl = "";
    private String animePoster = "";
    private String selectedAudio = "sub";
    private int selectedServer = 1;
    private boolean streamLaunched = false;
    private String currentEpTitle = "";

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        animeTitle = getIntent().getStringExtra("TITLE");
        animeUrl = getIntent().getStringExtra("URL");
        animePoster = getIntent().getStringExtra("POSTER");
        if (animeTitle == null) animeTitle = "Anime";
        if (animeUrl == null) animeUrl = AniWaveScraper.BASE_URL + "/home";
        if (animePoster == null) animePoster = "";

        tvDetailTitle = findViewById(R.id.tvDetailTitle);
        tvDetailHeader = findViewById(R.id.tvDetailHeader);
        tvDetailSynopsis = findViewById(R.id.tvDetailSynopsis);
        tvDetailMeta = findViewById(R.id.tvDetailMeta);
        tvExtractingStatus = findViewById(R.id.tvExtractingStatus);
        ivDetailPoster = findViewById(R.id.ivDetailPoster);
        hiddenExtractor = findViewById(R.id.hiddenExtractorWebView);

        btnModeSub = findViewById(R.id.btnModeSub);
        btnModeDub = findViewById(R.id.btnModeDub);
        btnServer1 = findViewById(R.id.btnServer1);
        btnServer2 = findViewById(R.id.btnServer2);
        btnServer3 = findViewById(R.id.btnServer3);

        TextView btnBack = findViewById(R.id.btnDetailBack);
        TextView btnBookmark = findViewById(R.id.btnDetailBookmark);
        RecyclerView rvEpisodes = findViewById(R.id.rvEpisodes);

        tvDetailTitle.setText(animeTitle);
        tvDetailHeader.setText(animeTitle);
        if (!animePoster.isEmpty()) {
            Glide.with(this).load(animePoster).centerCrop().into(ivDetailPoster);
        }

        btnBack.setOnClickListener(v -> finish());
        btnBookmark.setOnClickListener(v -> saveToMyList());

        setupAudioAndServerSelectors();
        setupHiddenExtractor();

        rvEpisodes.setLayoutManager(new GridLayoutManager(this, 5));
        episodeAdapter = new EpisodeAdapter(this, this::extractAndPlayEpisode);
        rvEpisodes.setAdapter(episodeAdapter);

        loadDetails();
    }

    private void setupAudioAndServerSelectors() {
        SharedPreferences prefs = getSharedPreferences("AniWaveNativePrefs", MODE_PRIVATE);
        if (prefs.getBoolean("prefer_dub", false)) {
            selectedAudio = "dub";
            btnModeSub.setBackgroundResource(R.drawable.bg_chip);
            btnModeDub.setBackgroundResource(R.drawable.bg_chip_active);
        }

        btnModeSub.setOnClickListener(v -> {
            selectedAudio = "sub";
            btnModeSub.setBackgroundResource(R.drawable.bg_chip_active);
            btnModeDub.setBackgroundResource(R.drawable.bg_chip);
        });

        btnModeDub.setOnClickListener(v -> {
            selectedAudio = "dub";
            btnModeDub.setBackgroundResource(R.drawable.bg_chip_active);
            btnModeSub.setBackgroundResource(R.drawable.bg_chip);
        });

        View.OnClickListener serverClick = v -> {
            btnServer1.setBackgroundResource(R.drawable.bg_chip);
            btnServer2.setBackgroundResource(R.drawable.bg_chip);
            btnServer3.setBackgroundResource(R.drawable.bg_chip);
            v.setBackgroundResource(R.drawable.bg_chip_active);
            if (v.getId() == R.id.btnServer1) selectedServer = 1;
            else if (v.getId() == R.id.btnServer2) selectedServer = 2;
            else selectedServer = 3;
        };
        btnServer1.setOnClickListener(serverClick);
        btnServer2.setOnClickListener(serverClick);
        btnServer3.setOnClickListener(serverClick);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupHiddenExtractor() {
        WebSettings ws = hiddenExtractor.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setUserAgentString("Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36");

        hiddenExtractor.setWebChromeClient(new WebChromeClient());
        hiddenExtractor.setWebViewClient(new WebViewClient() {
            @Nullable
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (AdBlocker.isAdUrl(url)) {
                    return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream("".getBytes()));
                }
                if (!streamLaunched && AdBlocker.isStreamUrl(url)) {
                    streamLaunched = true;
                    runOnUiThread(() -> {
                        tvExtractingStatus.setVisibility(View.GONE);
                        hiddenExtractor.stopLoading();
                        Intent intent = new Intent(DetailActivity.this, PlayerActivity.class);
                        intent.putExtra("STREAM_URL", url);
                        intent.putExtra("REFERER", animeUrl);
                        intent.putExtra("TITLE", currentEpTitle);
                        startActivity(intent);
                    });
                }
                return super.shouldInterceptRequest(view, request);
            }
        });
    }

    private void extractAndPlayEpisode(EpisodeItem ep) {
        streamLaunched = false;
        currentEpTitle = animeTitle + " · Ep " + ep.number + " (" + selectedAudio.toUpperCase() + " · S" + selectedServer + ")";
        tvExtractingStatus.setVisibility(View.VISIBLE);
        tvExtractingStatus.setText("Extracting " + selectedAudio.toUpperCase() + " Server " + selectedServer + " stream for Ep " + ep.number + "...");
        hiddenExtractor.loadUrl(ep.url);
    }

    private void loadDetails() {
        executor.execute(() -> {
            try {
                AniWaveScraper.AnimeDetailData data = AniWaveScraper.fetchAnimeDetails(animeUrl);
                runOnUiThread(() -> {
                    if (!data.title.isEmpty()) {
                        animeTitle = data.title;
                        tvDetailTitle.setText(data.title);
                        tvDetailHeader.setText(data.title);
                    }
                    if (!data.synopsis.isEmpty()) {
                        tvDetailSynopsis.setText(data.synopsis);
                    } else {
                        tvDetailSynopsis.setText("Tap any episode below to stream in Native ExoPlayer.");
                    }
                    if (!data.posterUrl.isEmpty() && animePoster.isEmpty()) {
                        animePoster = data.posterUrl;
                        Glide.with(DetailActivity.this).load(animePoster).centerCrop().into(ivDetailPoster);
                    }
                    tvDetailMeta.setText(data.meta + " · " + data.episodes.size() + " Episodes");
                    episodeAdapter.setEpisodes(data.episodes);
                });
            } catch (Exception e) {
                runOnUiThread(() -> tvDetailSynopsis.setText("Could not load details. Check internet."));
            }
        });
    }

    private void saveToMyList() {
        SharedPreferences prefs = getSharedPreferences("AniWaveNativePrefs", MODE_PRIVATE);
        Set<String> saved = new HashSet<>(prefs.getStringSet("my_list", new HashSet<>()));
        saved.add(animeTitle + "|||" + animeUrl + "|||" + animePoster);
        prefs.edit().putStringSet("my_list", saved).apply();
        Toast.makeText(this, "Added to My List", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (hiddenExtractor != null) {
            hiddenExtractor.destroy();
        }
    }
}
