package com.vrksignatures.aniwave;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class AniWaveScraper {
    public static final String BASE_URL = "https://aniwaves.tv";
    private static final String UA = "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36";

    private static final OkHttpClient client = new OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .followRedirects(true)
            .build();

    public static String fetchHtml(String url) throws IOException {
        Request request = new Request.Builder()
                .url(url)
                .header("User-Agent", UA)
                .header("Referer", BASE_URL + "/home")
                .build();
        try (Response response = client.newCall(request).execute()) {
            if (response.body() != null) {
                return response.body().string();
            }
        }
        return "";
    }

    public static List<AnimeItem> fetchAnimeList(String pageUrl) throws IOException {
        List<AnimeItem> list = new ArrayList<>();
        Set<String> seenUrls = new HashSet<>();
        String html = fetchHtml(pageUrl);
        if (html.isEmpty()) return list;

        Document doc = Jsoup.parse(html, BASE_URL);
        Elements cards = doc.select("div.item, div.flw-item, article.bs, div.ani.items > div");

        for (Element card : cards) {
            Element linkEl = card.selectFirst("a[href*=/watch/], a[href*=/anime/], a.name, a.d-title, a[href]");
            if (linkEl == null) continue;

            String href = linkEl.absUrl("href");
            if (href.isEmpty() || seenUrls.contains(href)) continue;

            Element imgEl = card.selectFirst("img");
            String poster = "";
            if (imgEl != null) {
                poster = imgEl.hasAttr("data-src") ? imgEl.absUrl("data-src") : imgEl.absUrl("src");
                if (poster.isEmpty()) poster = imgEl.attr("data-src");
                if (poster.isEmpty()) poster = imgEl.attr("src");
            }
            if (poster.isEmpty()) continue;

            String title = "";
            Element titleEl = card.selectFirst(".name, .d-title, .film-name a, .title, h3");
            if (titleEl != null) {
                title = titleEl.text().trim();
            }
            if (title.isEmpty()) {
                title = linkEl.attr("title").trim();
            }
            if (title.isEmpty()) {
                title = linkEl.text().trim();
            }
            if (title.isEmpty()) continue;

            String jpTitle = titleEl != null && titleEl.hasAttr("data-jp") ? titleEl.attr("data-jp").trim() : title;
            String sub = extractText(card, ".sub, .tick-sub, .ep-status.sub");
            String dub = extractText(card, ".dub, .tick-dub, .ep-status.dub");
            String type = extractText(card, ".type, .fdi-item, .right");
            if (type.isEmpty()) type = "TV";
            if (sub.isEmpty()) sub = "SUB";

            seenUrls.add(href);
            list.add(new AnimeItem(title, jpTitle, href, poster, sub, dub, type));
        }
        return list;
    }

    public static List<AnimeItem> searchAnime(String query) throws IOException {
        String encoded = URLEncoder.encode(query.trim(), "UTF-8");
        return fetchAnimeList(BASE_URL + "/filter?keyword=" + encoded);
    }

    public static class AnimeDetailData {
        public String title = "";
        public String synopsis = "";
        public String meta = "TV · HD";
        public String posterUrl = "";
        public List<EpisodeItem> episodes = new ArrayList<>();
    }

    public static AnimeDetailData fetchAnimeDetails(String detailUrl) throws IOException {
        AnimeDetailData data = new AnimeDetailData();
        String html = fetchHtml(detailUrl);
        if (html.isEmpty()) return data;

        Document doc = Jsoup.parse(html, BASE_URL);
        Element titleEl = doc.selectFirst("h1.title, h1.names, h2.film-name, h1");
        if (titleEl != null) data.title = titleEl.text().trim();

        Element synEl = doc.selectFirst(".synopsis .content, .description, .film-description, .shorting");
        if (synEl != null) data.synopsis = synEl.text().trim();

        Element imgEl = doc.selectFirst(".poster img, .film-poster img, img[src]");
        if (imgEl != null) {
            data.posterUrl = imgEl.hasAttr("data-src") ? imgEl.absUrl("data-src") : imgEl.absUrl("src");
        }

        // Parse episodes if directly present in HTML
        Elements epEls = doc.select("ul.episodes a, .ep-item, .episodes a[data-num], a[href*=/ep-]");
        Set<String> seenEp = new HashSet<>();
        int idx = 1;
        for (Element ep : epEls) {
            String epUrl = ep.absUrl("href");
            if (epUrl.isEmpty() || seenEp.contains(epUrl)) continue;
            String num = ep.hasAttr("data-num") ? ep.attr("data-num") : ep.text().trim();
            if (num.isEmpty()) num = String.valueOf(idx);
            seenEp.add(epUrl);
            data.episodes.add(new EpisodeItem(num, epUrl));
            idx++;
        }

        // Fallback: if episodes are loaded dynamically via JS, provide Episode 1..12 mapped to watch URL
        if (data.episodes.isEmpty()) {
            String baseWatch = detailUrl.endsWith("/") ? detailUrl.substring(0, detailUrl.length() - 1) : detailUrl;
            for (int i = 1; i <= 12; i++) {
                data.episodes.add(new EpisodeItem(String.valueOf(i), baseWatch + "/ep-" + i));
            }
        }
        return data;
    }

    private static String extractText(Element parent, String cssQuery) {
        Element el = parent.selectFirst(cssQuery);
        return el != null ? el.text().trim() : "";
    }
}
