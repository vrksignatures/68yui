package com.vrksignatures.aniwave;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "AniWaveNativePrefs";
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private SwipeRefreshLayout swipeRefresh;
    private LinearLayout searchContainer, myListContainer, settingsContainer;
    private TextView tvHomeStatus, tvSearchStatus, tvMyListEmpty, btnLangToggle;
    private TextView chipAll, chipSub, chipDub, chipTrending, chipTop;
    private EditText etSearch;

    private AnimeAdapter homeAdapter, searchAdapter, myListAdapter;
    private SharedPreferences prefs;
    private boolean useJpTitles = false;
    private String currentHomeUrl = AniWaveScraper.BASE_URL + "/home";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        swipeRefresh = findViewById(R.id.swipeRefresh);
        searchContainer = findViewById(R.id.searchContainer);
        myListContainer = findViewById(R.id.myListContainer);
        settingsContainer = findViewById(R.id.settingsContainer);
        tvHomeStatus = findViewById(R.id.tvHomeStatus);
        tvSearchStatus = findViewById(R.id.tvSearchStatus);
        tvMyListEmpty = findViewById(R.id.tvMyListEmpty);
        btnLangToggle = findViewById(R.id.btnLangToggle);
        etSearch = findViewById(R.id.etSearch);
        Button btnSearchGo = findViewById(R.id.btnSearchGo);
        Switch switchPreferDub = findViewById(R.id.switchPreferDub);
        Button btnClearHistory = findViewById(R.id.btnClearHistory);
        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);

        chipAll = findViewById(R.id.chipAll);
        chipSub = findViewById(R.id.chipSub);
        chipDub = findViewById(R.id.chipDub);
        chipTrending = findViewById(R.id.chipTrending);
        chipTop = findViewById(R.id.chipTop);

        RecyclerView rvHome = findViewById(R.id.rvHomeAnime);
        RecyclerView rvSearch = findViewById(R.id.rvSearchResults);
        RecyclerView rvMyList = findViewById(R.id.rvMyList);

        rvHome.setLayoutManager(new GridLayoutManager(this, 3));
        rvSearch.setLayoutManager(new GridLayoutManager(this, 3));
        rvMyList.setLayoutManager(new GridLayoutManager(this, 3));

        AnimeAdapter.OnAnimeClickListener clickListener = this::openAnimeDetail;
        homeAdapter = new AnimeAdapter(this, clickListener);
        searchAdapter = new AnimeAdapter(this, clickListener);
        myListAdapter = new AnimeAdapter(this, clickListener);

        rvHome.setAdapter(homeAdapter);
        rvSearch.setAdapter(searchAdapter);
        rvMyList.setAdapter(myListAdapter);

        btnLangToggle.setOnClickListener(v -> {
            useJpTitles = !useJpTitles;
            btnLangToggle.setText(useJpTitles ? "JP" : "EN");
            homeAdapter.setUseJapaneseTitle(useJpTitles);
            searchAdapter.setUseJapaneseTitle(useJpTitles);
            myListAdapter.setUseJapaneseTitle(useJpTitles);
        });

        setupFilterChips();

        swipeRefresh.setOnRefreshListener(() -> loadHomeAnime(currentHomeUrl));

        btnSearchGo.setOnClickListener(v -> performSearch());
        etSearch.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                performSearch();
                return true;
            }
            return false;
        });

        switchPreferDub.setChecked(prefs.getBoolean("prefer_dub", false));
        switchPreferDub.setOnCheckedChangeListener((b, isChecked) ->
                prefs.edit().putBoolean("prefer_dub", isChecked).apply());

        btnClearHistory.setOnClickListener(v -> {
            prefs.edit().remove("my_list").apply();
            Toast.makeText(this, "Saved List & History Cleared", Toast.LENGTH_SHORT).show();
            loadMyList();
        });

        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            swipeRefresh.setVisibility(View.GONE);
            searchContainer.setVisibility(View.GONE);
            myListContainer.setVisibility(View.GONE);
            settingsContainer.setVisibility(View.GONE);

            if (id == R.id.nav_home) {
                swipeRefresh.setVisibility(View.VISIBLE);
                return true;
            } else if (id == R.id.nav_search) {
                searchContainer.setVisibility(View.VISIBLE);
                return true;
            } else if (id == R.id.nav_mylist) {
                myListContainer.setVisibility(View.VISIBLE);
                loadMyList();
                return true;
            } else if (id == R.id.nav_settings) {
                settingsContainer.setVisibility(View.VISIBLE);
                return true;
            }
            return false;
        });

        loadHomeAnime(currentHomeUrl);
    }

    private void setupFilterChips() {
        View.OnClickListener chipClick = v -> {
            chipAll.setBackgroundResource(R.drawable.bg_chip);
            chipSub.setBackgroundResource(R.drawable.bg_chip);
            chipDub.setBackgroundResource(R.drawable.bg_chip);
            chipTrending.setBackgroundResource(R.drawable.bg_chip);
            chipTop.setBackgroundResource(R.drawable.bg_chip);
            v.setBackgroundResource(R.drawable.bg_chip_active);

            int id = v.getId();
            if (id == R.id.chipAll) currentHomeUrl = AniWaveScraper.BASE_URL + "/home";
            else if (id == R.id.chipSub) currentHomeUrl = AniWaveScraper.BASE_URL + "/filter?language%5B%5D=sub";
            else if (id == R.id.chipDub) currentHomeUrl = AniWaveScraper.BASE_URL + "/filter?language%5B%5D=dub";
            else if (id == R.id.chipTrending) currentHomeUrl = AniWaveScraper.BASE_URL + "/trending";
            else if (id == R.id.chipTop) currentHomeUrl = AniWaveScraper.BASE_URL + "/ongoing";

            loadHomeAnime(currentHomeUrl);
        };

        chipAll.setOnClickListener(chipClick);
        chipSub.setOnClickListener(chipClick);
        chipDub.setOnClickListener(chipClick);
        chipTrending.setOnClickListener(chipClick);
        chipTop.setOnClickListener(chipClick);
    }

    private void loadHomeAnime(String url) {
        swipeRefresh.setRefreshing(true);
        tvHomeStatus.setVisibility(View.VISIBLE);
        tvHomeStatus.setText("Loading anime...");

        executor.execute(() -> {
            try {
                List<AnimeItem> result = AniWaveScraper.fetchAnimeList(url);
                runOnUiThread(() -> {
                    swipeRefresh.setRefreshing(false);
                    if (result.isEmpty()) {
                        tvHomeStatus.setText("No anime loaded. Pull down to refresh.");
                        tvHomeStatus.setVisibility(View.VISIBLE);
                    } else {
                        tvHomeStatus.setVisibility(View.GONE);
                        homeAdapter.setItems(result);
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    swipeRefresh.setRefreshing(false);
                    tvHomeStatus.setText("Network error. Pull down to retry.");
                    tvHomeStatus.setVisibility(View.VISIBLE);
                });
            }
        });
    }

    private void performSearch() {
        String q = etSearch.getText().toString().trim();
        if (q.isEmpty()) return;
        tvSearchStatus.setVisibility(View.VISIBLE);
        tvSearchStatus.setText("Searching for \"" + q + "\"...");

        executor.execute(() -> {
            try {
                List<AnimeItem> res = AniWaveScraper.searchAnime(q);
                runOnUiThread(() -> {
                    if (res.isEmpty()) {
                        tvSearchStatus.setText("No results found for \"" + q + "\".");
                    } else {
                        tvSearchStatus.setVisibility(View.GONE);
                    }
                    searchAdapter.setItems(res);
                });
            } catch (Exception e) {
                runOnUiThread(() -> tvSearchStatus.setText("Search failed. Check internet."));
            }
        });
    }

    private void loadMyList() {
        Set<String> saved = prefs.getStringSet("my_list", new HashSet<>());
        List<AnimeItem> items = new ArrayList<>();
        for (String entry : saved) {
            String[] p = entry.split("\\|\\|\\|");
            if (p.length >= 3) {
                items.add(new AnimeItem(p[0], p[0], p[1], p[2], "SUB", "", "TV"));
            }
        }
        myListAdapter.setItems(items);
        tvMyListEmpty.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void openAnimeDetail(AnimeItem item) {
        Intent intent = new Intent(this, DetailActivity.class);
        intent.putExtra("TITLE", item.title);
        intent.putExtra("URL", item.url);
        intent.putExtra("POSTER", item.posterUrl);
        startActivity(intent);
    }
}
